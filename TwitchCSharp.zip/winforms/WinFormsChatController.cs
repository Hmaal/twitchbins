﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Twitch;
using ErrorCode = Twitch.ErrorCode;

namespace Twitch.Chat
{
    public partial class ChatController
    {
        #region Memeber Variables

        protected string m_ClientId = "";
        protected string m_ClientSecret = "";
        protected string m_CaCertFilePath = "";
        protected Twitch.Chat.Chat m_Chat = null;

        #endregion

        #region Properties

        protected string DefaultCaCertFilePath
        {
            get { return "./curl-ca-bundle.crt"; }
        }

        #endregion

        public ChatController()
        {
            m_Chat = new Twitch.Chat.Chat(new Twitch.Chat.CoreChatAPI());
        }

        protected void CheckError(ErrorCode err)
        {
            if (err != ErrorCode.TTV_EC_SUCCESS)
            {
                System.Windows.Forms.MessageBox.Show(err.ToString());
            }
        }

        protected void ReportError(string err)
        {
            System.Windows.Forms.MessageBox.Show(err, "Error");
        }

        protected void ReportWarning(string err)
        {
            System.Windows.Forms.MessageBox.Show(err, "Warning");
        }
    }
}
